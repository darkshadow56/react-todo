import React, {useState, useContext} from 'react';
import {FormGroup, Input, Button, Form, InputGroup, InputGroupAddon} from 'reactstrap';
import {v4} from 'uuid';
import {TodoContext} from '../context/TodoContext';
import {ADD_TODO} from '../context/action.types';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';



const TodoForm = () => {
    const [todoString, setTodoString] = useState("");
    const {dispatch} = useContext(TodoContext);
  
    function handleSubmit(e) {
    e.preventDefault();
    if (todoString === "") {
      return toast("Please add a task!");
    }

    const todo = {
      todoString,
      id: v4()
    };
    dispatch({
      type: ADD_TODO,
      payload: todo,
    });

    setTodoString("");
  }
    return(
<Form onSubmit={handleSubmit}>
    <FormGroup>
        <InputGroup>
        <Input  type='submit' name='todo' id='todo' placeholder='Your Next Todo' value={todoString} onChange={e => setTodoString(e.target.value)}/>
        <InputGroupAddon addonType='prepend'>
        <Button color='warning' type='submit'>Add Task</Button>
        </InputGroupAddon>        
        </InputGroup>
    </FormGroup>
</Form>
    )
}
export default TodoForm;